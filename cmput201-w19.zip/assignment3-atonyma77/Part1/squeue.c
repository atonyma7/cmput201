//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#include <stdbool.h>
#include "squeue.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>

void initSqueue (Squeue ** squeue){
	*squeue = malloc(sizeof(Squeue));
	(*squeue)->first = NULL;
	(*squeue)->last = NULL;
	return;
	
}
bool isEmpty (const Squeue *squeue){
	//If both the first and last are NULL, then the squeue is empty, this condition will always be true
	if (squeue->first == NULL && squeue->last == NULL){
		return true;
	}
	return false;
}
void addFront (Squeue *squeue, char* val){
	
	//create a new node
	struct Node *new_node;
	new_node = malloc(sizeof(struct Node));
	new_node->val = malloc(strlen(val)+1);
	strcpy(new_node->val, val);
	
	//if the list is not empty, set the prev of the first node to point to the new node
	if (squeue->first != NULL){
		squeue->first->prev = new_node;
	}
	
	//set properties of new_node
	new_node->prev = NULL;
	new_node->next = squeue->first;
	squeue->first = new_node;
	
	if(squeue->last == NULL){
		squeue->last = new_node;
	}
	return;
}

void addBack (Squeue *squeue, char* val){
	//intialize a new node with a new value
	struct Node *new_node;
	new_node = malloc(sizeof(struct Node));
	new_node->val = malloc(strlen(val)+1);
	strcpy(new_node->val, val);
	
	//if the list is not empty, set the next of the current last node to the new_node (appending at the end of the list)
	if (squeue->last != NULL){
		squeue->last->next = new_node;
	}
	
	//set properties of new_node
	new_node->prev = squeue->last;
	new_node->next = NULL;
	squeue->last = new_node;
	
	if(squeue->first == NULL){
		squeue->first = new_node;
	}
	return;
}
void leaveFront (Squeue *squeue){
	//make sure squeue is not empty
	assert (!isEmpty(squeue));
	
	//if there is only one node in the squeue, set the first and last of squeue to NULL since the squeue is now empty
	if (squeue->first == squeue->last){
		struct Node *temp = squeue->first;
		squeue->first = NULL;
		squeue->last = NULL;
		free(temp->val);
		free(temp);
	}
	
	//if there is more an one node in the squeue, remove the first node
	else{
		struct Node *temp = squeue->first;
		squeue->first->next->prev = NULL;
		squeue->first = squeue->first->next;
		free(temp->val);
		free(temp);
	}
	return;
}
char* peekBack (const Squeue *squeue){
	assert (!isEmpty(squeue));
	return squeue->last->val;
}
void leaveBack (Squeue *squeue){
	//make sure squeue is not empty
	assert (!isEmpty(squeue));
	
	//if there is only one node in the squeue, set the first and last of squeue to NULL since the squeue is now empty
	if (squeue->first == squeue->last){
		struct Node *temp = squeue->last;
		squeue->first = NULL;
		squeue->last = NULL;
		free(temp->val);
		free(temp);
	}
	//if there is more an one node in the squeue, remove the first node
	else{
		struct Node *temp = squeue->last;
		squeue->last->prev->next = NULL;
		squeue->last = squeue->last->prev;
		free(temp->val);
		free(temp);
	}
	return;
}
char* peekFront (const Squeue *squeue){
	assert (!isEmpty(squeue));
	return squeue->first->val;
}
void print (const Squeue *squeue, char direction){
	struct Node *p;
	
	//print in forward direction
	if (direction == 'f'){
		printf("stack is:\n");
		p = squeue->first;
		for (; p != NULL; p = p->next){
			printf("\t%s\n", p->val);
		}
	}
	//print in reverse order
	else if (direction == 'r'){
		printf("stack is:\n");
		p = squeue->last;
		for (; p != NULL; p = p->prev){
			printf("\t%s\n", p->val);
		}
		
	//raise an error if illegal direction is detected
	}
	else{
		fprintf(stderr, "Error, illegal direction %c\n", direction);
		return;
	}

	return;
}
void nuke (Squeue *squeue){
	
	//delete all values in the nodes, then delete the nodes
	struct Node *p;
	struct Node *temp;
	p = squeue->first;
	 while (p != NULL){
       temp = p;
       p = p->next;
	   free(temp->val);
       free(temp);
    }
	squeue->first = NULL;
	squeue->last = NULL;
	return;
}
void mergeFront(Squeue *squeue, char direction ){
	//Make sure squeue is not empty and that there are more than 2 elements
	assert(squeue->first != NULL && squeue->first->next != NULL);
	assert(squeue->first->next != NULL);
	int length = strlen(squeue->first->val) + strlen(squeue->first->next->val) + 1;
	char *new_word = malloc(length);
	
	//Copy the first 2 words into the first word
	if (direction == 'f'){
		strcpy(new_word, squeue->first->val);
		strcat(new_word, squeue->first->next->val);
		squeue->first->val = realloc(squeue->first->val, length);
		strcpy(squeue->first->val, new_word);
	}
	else if (direction == 'r'){
		strcpy(new_word, squeue->first->next->val);
		strcat(new_word, squeue->first->val);
		squeue->first->val = realloc(squeue->first->val, length);
		strcpy(squeue->first->val, new_word);
	}
	//throw error if direction is illegal
	else{
		free(new_word);
		fprintf(stderr, "Error, illegal direction %c\n", direction);
		return;
	}
	
	free(new_word);
	
	//Case for if there are only 2 elements in the squeue
	if (squeue->first->next->next == NULL){
		struct Node *temp = squeue->first->next;
		squeue->first->next = NULL;
		squeue->last = squeue->first;
		free(temp->val);
		free(temp);
	}
	
	//Case for if there are more than 2 elements in the squeue
	else if (squeue->first->next->next != NULL){
		struct Node *temp = squeue->first->next;
		squeue->first->next->next->prev = squeue->first;
		squeue->first->next = squeue->first->next->next;
		free(temp->val);
		free(temp);
		
	}
	return;

}
void mergeBack(Squeue *squeue, char direction){
	//Make sure squeue is not empty and that there are more than 2 elements
	assert(squeue->first != NULL && squeue->first->next != NULL);
	assert(squeue->first->next != NULL);
	int length = strlen(squeue->last->val) + strlen(squeue->last->prev->val) + 1;
	char *new_word = malloc(length);
	
	//Copy the first 2 words into the second last word
	if (direction == 'f'){
		strcpy(new_word, squeue->last->prev->val);
		strcat(new_word, squeue->last->val);
		squeue->last->prev->val = realloc(squeue->last->prev->val, length);
		strcpy(squeue->last->prev->val, new_word);
	}
	else if (direction == 'r'){
		strcpy(new_word, squeue->last->val);
		strcat(new_word, squeue->last->prev->val);
		squeue->last->prev->val = realloc(squeue->last->prev->val, length);
		strcpy(squeue->last->prev->val, new_word);
	}
	
	//throw error if illegal direction detected
	else{
		free(new_word);
		fprintf(stderr, "Error, illegal direction %c\n", direction);
		return;
	}
	free(new_word);
	
	struct Node *temp = squeue->last;
	squeue->last->prev->next = NULL;
	squeue->last = squeue->last->prev;
	free(temp->val);
	free(temp);
	return;
}
void reverse(Squeue *squeue){
	struct Node *p = squeue->first;
	
	//reverse next and prev of each node, iterate through the list by going to the prev of the node, not the next, since they are switched in the loop
	for (; p != NULL; p = p->prev){
		struct Node *temp;
		temp = p->next;
		p->next = p->prev;
		p->prev = temp;
	}
	
	//swap first and last
	struct Node *temp;
	temp = squeue->first;
	squeue->first = squeue->last;
	squeue->last = temp;
	return;
	
}
void destroySqueue(Squeue **squeue){
	
	//same as nuke, but also destroy the sqeue itself
	struct Node *p;
	struct Node *temp;
	p = (*squeue)->first;
	 while (p != NULL){
       temp = p;
       p = p->next;
	   free(temp->val);
       free(temp);
    }
	(*squeue)->first = NULL;
	(*squeue)->last = NULL;
	free(*squeue);
	*squeue = NULL;
	return;
}