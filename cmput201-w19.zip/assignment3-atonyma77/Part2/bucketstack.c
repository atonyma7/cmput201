//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#include "bucketstack.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void initStack (int bucketSize, Stack **stack){
	assert(bucketSize > 0);
	*stack = malloc(sizeof(Stack));
	(*stack)->topElt = 0;
	(*stack)->firstBucket = NULL;
	(*stack)->bucketSize = bucketSize;
	return;
}
bool isEmpty (const Stack *stack){
	
	//If ethier the first Bucket doesn't exist, or if there is only one empty bucket in the queue, then the stack is empty
	if (stack->firstBucket == NULL){
		return true;
	}
	else{
		if (stack->firstBucket->next == NULL && stack->firstBucket->val[0] == NULL){
			return true;
		}
	}
	
	return false;
}
void push (char* val, Stack *stack){
	
	//If the first bucket doesn't yet exist, create a first bucket then push in an element at index 0.
	if (stack->firstBucket == NULL){
		
		struct NodeBucket *new_bucket;
		new_bucket = malloc(sizeof(struct NodeBucket));
		new_bucket->val = malloc(sizeof(char*) * stack->bucketSize);
		for (int index = 0; index < stack->bucketSize; index++){
			new_bucket->val[index] = NULL;
		}

		new_bucket->next = NULL;
		
		stack->firstBucket = new_bucket;
		
		new_bucket->val[0] = malloc(strlen(val)+1);
		strcpy(new_bucket->val[0], val);
		stack->topElt = 0;
	}
	
	//if the first bucket is not full, push element
	else if (stack->topElt != (stack->bucketSize-1)){
		stack->topElt++;
		stack->firstBucket->val[stack->topElt] = malloc(strlen(val)+1);
		strcpy(stack->firstBucket->val[stack->topElt], val);
	}
	
	//if the first bucket is full, create new bucket and push element in, setting TopElt to 0
	else if (stack->topElt == (stack->bucketSize-1)){
		struct NodeBucket *new_bucket;
		new_bucket = malloc(sizeof(struct NodeBucket));
		new_bucket->val = malloc(sizeof(char*) * stack->bucketSize);
		for (int index = 0; index < stack->bucketSize; index++){
			new_bucket->val[index] = NULL;
		}
		
		new_bucket->next = stack->firstBucket;
		
		stack->firstBucket = new_bucket;
		
		new_bucket->val[0] = malloc(strlen(val)+1);
		strcpy(new_bucket->val[0], val);
		stack->topElt = 0;
	}
	return;
	
}
void pop(Stack *stack){
	assert (!isEmpty(stack));
	//Free the element to be popped
	free(stack->firstBucket->val[stack->topElt]);
	stack->firstBucket->val[stack->topElt] = NULL;
	
	//if the element to be popped is the last element of the array, set firstBucket to the second bucket
	if (stack->topElt == 0){
		struct NodeBucket *temp = stack->firstBucket;
		stack->firstBucket = stack->firstBucket->next;
		free(temp->val);
		free(temp);
		stack->topElt = stack->bucketSize - 1;
	}
	else{
		stack->topElt--;
	}
	
	return;
}
int size (const Stack *stack){
	int count = 0;
	struct NodeBucket *p;
	p = stack->firstBucket;
	while (p != NULL){
		for (int index = 0; index < stack->bucketSize; index++){
			if (p->val[index] != NULL){
				count++;
			}
		}
		p = p->next;
	}
	return count;
}
char* top (const Stack *stack){
	return stack->firstBucket->val[stack->topElt];
}
void swap (Stack *stack){
	
	//assert that there are more than 2 elements in the stack
	assert (!isEmpty(stack));
	assert (size(stack) >= 2);
	
	//if the element to be swapped is the last element of the first bucket, swap it with the bottom element of the next bucket
	if (stack->topElt == 0){
		char temp[strlen(stack->firstBucket->val[stack->topElt])+1];
		strcpy(temp, stack->firstBucket->val[stack->topElt]);
	
		stack->firstBucket->val[stack->topElt] = realloc(stack->firstBucket->val[stack->topElt], strlen(stack->firstBucket->next->val[stack->bucketSize-1])+1);
		strcpy(stack->firstBucket->val[stack->topElt], stack->firstBucket->next->val[stack->bucketSize-1]);
	
		stack->firstBucket->next->val[stack->bucketSize-1]= realloc(stack->firstBucket->next->val[stack->bucketSize-1], strlen(temp)+1);
		strcpy(stack->firstBucket->next->val[stack->bucketSize-1], temp);
	}
	//otherwise just swap the top 2 elements of the firstBucket
	else{
		char *temp;
	
		temp = stack->firstBucket->val[stack->topElt];
	
		stack->firstBucket->val[stack->topElt] = stack->firstBucket->val[stack->topElt - 1];
		stack->firstBucket->val[stack->topElt - 1] = temp;
	}
	
	return;
}
void print (const Stack *stack){
	struct NodeBucket *p;
	p = stack->firstBucket;
	printf("stack is:\n");
	while (p != NULL){
		for (int index = stack->bucketSize-1; index >=  0; index--){
			if (p->val[index] != NULL){
				printf("\t%s\n", p->val[index]);
			}
		}
		p = p->next;
	}
	return;
}
void clear(Stack *stack){
	//free and remove all nodes and the values they contain
	struct NodeBucket *p;
	struct NodeBucket *temp;
	p = stack->firstBucket;
	while (p != NULL){
		temp = p;
		p = p->next;
		for (int index = 0; index < stack->bucketSize; index++){
			if (temp->val[index] != NULL){
				free(temp->val[index]);
			}
		}
		free(temp->val);
		free(temp);
	}
	stack->firstBucket = NULL;
	return;
}
void destroyStack(Stack **stack){
	//same as clear(), but also destroy the Stack
	struct NodeBucket *p;
	struct NodeBucket *temp;
	p = (*stack)->firstBucket;
	while (p != NULL){
		temp = p;
		p = p->next;
		for (int index = 0; index < (*stack)->bucketSize; index++){
			if (temp->val[index] != NULL){
				free(temp->val[index]);
			}
		}
		free(temp->val);
		free(temp);
	}
	(*stack)->firstBucket = NULL;
	free(*stack);
	*stack = NULL;
	return;
}