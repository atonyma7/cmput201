#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
 int studentID;
 char name[20];
} Student;

int main (void){
	int op;
	int index = 0;
	int found = 0;
	int spotsLeft = 5;
	Student **students = malloc(sizeof(Student *) * 2);
	
	int arraySize = 2;
	for (index = 0; index < arraySize; index++){
		students[index] = NULL;
	}
	
	while (1){
		printf("Enter operation: ");
		scanf("%d", &op);
		char name[20];
		if (op == 1){
			found = 0;
			Student *new_student = malloc(sizeof(Student));
			for (index = 0 ; index < arraySize ; index++){
				if (students[index] == NULL){
					found = 1;
					
					printf("Enter ID to add (%d avaliable): ", spotsLeft);
					scanf("%d", &(new_student->studentID));
					
					printf("Enter student name: ");
					scanf("%s", name);
					
					strcpy(new_student->name, name);
					students[index] = new_student;
					spotsLeft--;
					break;
				}
			}
			if (found == 0 && arraySize < 5){
				students = realloc(students, ++arraySize*sizeof(Student*));
				printf("Enter ID to add (%d avaliable): ", spotsLeft);
				scanf("%d", &(new_student->studentID));
				
				printf("Enter student name: ");
				scanf("%s", name);
				
				strcpy(new_student->name, name);
				students[arraySize-1] = new_student;
				spotsLeft--;
				
			}
			if (spotsLeft == 0){
				printf("You have reached the max number of students");
				break;
			}
		}
	
		else if (op == 2){
			int removeID;
			printf("Enter ID to drop: ");
			scanf("%d", &removeID);
			for (index = 0 ; index < arraySize ; index++){
				if (students[index] != NULL){
					if (students[index]->studentID == removeID){
						free(students[index]);
						students[index] = NULL;
						spotsLeft++;
						break;
					}
				}
			}
		}
		
		else if(op == 0){
			break;
		}
	}
	
	if ((5-spotsLeft) == 1){
		printf("You have 1 student in the class:\n");
	}
	
	else{
		printf("You have %d students in the class:\n", 5-spotsLeft);
	}
	for (index = 0 ; index < arraySize ; index++){
		if (students[index] != NULL){
			printf("%d, %s\n", students[index]->studentID, students[index]->name);
			free(students[index]);
		}
	}
	
	free(students);
	return 0;
}