#ifndef QUICKSORT_H
#define QUICKSORT_H

#include <stdio.h>

#define N 10

void quicksort(char *a[], char **low, char **high);
char **split(char *a[], char **low, char **high);

#endif /* QUICKSORT_H */