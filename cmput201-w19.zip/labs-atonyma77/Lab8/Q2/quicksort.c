#include "quicksort.h"
#include <stdio.h>

#define N 10

void quicksort(char *a[], char **low, char **high){

    char **middle;

    if (low >= high)
        return;

    middle = split(a, low, high);
    quicksort(a, low, middle - 1);
    quicksort(a, middle + 1, high);
}

char **split(char *a[], char **low, char **high){

    char part_element = **low;


    for(;;){

        while (*low < *high && part_element <= **high)
            high--;

        if(*low >= *high)
            break;

        **low = **high;
		*low++;

        while (*low < *high && **low <= part_element)
            *low++;

        if (*low >= *high)
            break;

        **high = **low;
		*high--;
    }

    **high = part_element;

    return high;
}