#include <stdio.h>

int gcd(int m, int n);

int main(void){
	printf ("Enter two integers: ");
	int m, n;
	
	scanf ("%d %d", &m, &n);
	
	printf ("Greatest common divisor: %d\n", gcd(m, n));
	
	return 0;
}

int gcd(int m, int n){
	
	int rem;
	
	if (n == 0){
		return m;
	}
	
	rem = m % n;
	m = n;
	n = rem;
	return gcd(m, n);
}