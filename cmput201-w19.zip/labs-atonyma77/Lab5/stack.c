/**
 * This is not a complete program
 * Taken from Ch 10, p220
 **/

#include "stack.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#define STACK_SIZE 10

/* external variables */
int contents[STACK_SIZE];
int top = 0;

void make_empty(void){
    top = 0;
}

bool is_empty(void){
    return top == 0;
}

bool is_full(void){
    return top == STACK_SIZE-1;
}


void push(int i){

    if (is_full()){
		fprintf(stderr, "Stack Overflow\n");
		exit(1);
	}
    else{
        contents[top++] = i;
	}
}

int pop(void){
    
    if (is_empty()){
		fprintf(stderr, "Stack Underflow\n");
		exit(1);
	}
    else{
        return contents[--top];
	}
}

int peek(void){
	return contents[top-1];
}