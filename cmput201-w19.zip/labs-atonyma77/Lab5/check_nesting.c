#include "stack.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
int main(void){
	char input[100];
	int index = 0;
	printf("Enter parentheses and/or braces: ");
	scanf("%s", input);
	for (index = 0; index < 100; index++){
		if (input[index] == '{' || input[index] == '('){
			push(input[index]);
		}
		
		else if (input[index] == '}'){
			if (peek() == '{'){
				pop();
			}
			else {
				printf("Parentheses are not nested properly\n");
				exit(1);
			}
		}
		else if (input[index] == ')'){
			if (peek() == '('){
				pop();
			}
			else {
				printf("Parentheses are not nested properly\n");
				exit(1);
			}
		}
	}
	
	if (is_empty()){
		printf ("Parentheses are nested properly\n");
	}
	else {
		printf("Parentheses are not nested properly\n");
	}
	return 0;
}
//
//questions about the code: What should it output if no parentheses or braces are entered? How long can the inital input go up to?