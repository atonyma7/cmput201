#ifndef __QUEUE_H__
#define __QUEUE_H__

typedef struct {
	struct node *first;
	struct node *last;
}queue;

struct node{
    int value;
    char marker;
    struct node *next;
};

void insert(queue *Queue, int value);
bool isEmpty(queue *Queue);
void removeFront(queue *Queue);
int returnFront(queue *Queue);
int returnBack(queue *Queue);
void print(queue *Queue);
void nuke(queue *Queue);

#endif