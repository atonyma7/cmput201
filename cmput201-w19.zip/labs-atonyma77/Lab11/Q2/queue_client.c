#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "queue.h"

int main(void){
	queue *Queue = malloc(sizeof(queue));
	Queue->first = NULL;
	Queue->last = NULL;
	int input;
	printf("Enter operation: ");
	scanf("%d", &input);
	int value;
	while (input != 0){
		if (input == 1){
			printf("Enter item to enter: ");
			scanf("%d", &value);
			insert(Queue, value);
		}
		
		else if (input == 2){
			removeFront(Queue);
		}
		else if (input == 3){
			printf("%d\n", returnFront(Queue));
		}
		else if (input == 4){
			printf("%d\n", returnBack(Queue));
		}
		else if (input == 5){
			print(Queue);
		}
		else if (input == 6){
			if (isEmpty(Queue)){
				printf ("Queue is empty\n");
			}
			else{
				printf("Queue is not empty\n");
			}
		}
		else if (input == 7){
			nuke(Queue);
		}
		printf("Enter operation: ");
		scanf("%d", &input);
	}
	nuke(Queue);
	free(Queue);
	return 0;
}