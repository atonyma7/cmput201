#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "queue.h"
#include <assert.h>

void insert(queue *Queue, int value){
	struct node *new_node = malloc(sizeof(struct node));
	new_node->value = value;
	new_node->next = NULL;
	
	if (Queue->first == NULL){
		Queue->first = new_node;
		Queue->last = new_node;
	}
	else{
		Queue->last->next = new_node;
		Queue->last = new_node;
	}
	
	return;
}	

bool isEmpty(queue *Queue){
	if (Queue->first == NULL && Queue->last == NULL){
		return true;
	}
	return false;
}

void removeFront(queue *Queue){
	
	if (isEmpty(Queue)){
		return;
	}
	else{
		struct node *temp;
		temp = Queue->first;
		Queue->first = Queue->first->next;
		if (Queue->first == NULL){
			Queue->last = NULL;
		}
		free(temp);
	}
	
	return;
}

int returnFront(queue *Queue){
	assert (Queue->first != NULL);
	return Queue->first->value;
}

int returnBack(queue *Queue){
	assert (Queue->last != NULL);
	return Queue->last->value;
}

void print(queue *Queue){
	struct node *p;
	for (p = Queue->first; p != NULL; p = p->next){
		printf("%d\n", p->value);
	}
}
void nuke(queue *Queue){
	struct node *p;
	struct node *temp;
	p = Queue->first;
	while (p != NULL){
       temp = p;
       p = p->next;
       free(temp);
    }
	Queue->first = NULL;
	Queue->last = NULL;
}