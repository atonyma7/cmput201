#include <stdio.h>
#include <string.h>
int main(void){
	int sizeHalf;
	char word[101], *indexp;
	printf ("Enter a message: ");
	fgets(word, 101, stdin);
	sizeHalf = (strlen(word) - 1) / 2;
	printf ("Reversal of first half: ");
	for (indexp = (word + sizeHalf) - 1; indexp >= word; indexp--){
		printf ("%c", *indexp);
	}
	printf("\n");
	return 0;
}
//word is equal to word[0]