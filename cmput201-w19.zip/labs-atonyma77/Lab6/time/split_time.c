#include <stdio.h>
#include <stdlib.h>
void split_time(long total_sec, int *hr, int *min, int *sec);

int main(int argc, char *argv[]){
	long total_sec;
	int hr = 0, min = 0, sec = 0, *hrp, *minp, *secp;
	secp = &sec;
	hrp = &hr;
	minp = &min;
	total_sec =  atoi(argv[1]);
	split_time(total_sec, hrp, minp, secp);
	printf("%.2d:%.2d:%.2d\n", hr, min, sec);
	return 0;
}

void split_time(long total_sec, int *hr, int *min, int *sec){
	total_sec %= 86400;
	*hr = total_sec / 3600;
	total_sec %= 3600;
	*min = total_sec / 60;
	total_sec %= 60;
	*sec = total_sec;
	return;
}