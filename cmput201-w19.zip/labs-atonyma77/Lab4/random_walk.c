#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void generate_random_walk (int n, int m, char walk[n][m]);
void print_array (int n, int m, char walk[n][m]);

int main (void){
	int rows, cols;
	
	printf("Enter number of rows: ");
	scanf("%d", &rows);
	printf("Enter number of columns: ");
	scanf("%d", &cols);
	
	char walk[rows][cols];
	int i, j;
	
	for (i=0; i<rows; i++){
		for (j=0; j<cols; j++){
			walk[i][j] = '.';
		}
	}
	
	generate_random_walk (rows, cols, walk);
	print_array (rows, cols, walk);

	return 0;
}

void generate_random_walk (int n, int m, char walk[n][m]){
	srand(time(0));
	int x = 0, y= 0, movement;
	char ch;
	ch = 'A';
	walk[x][y] = ch;
	while (ch < 'Z'){
		movement = rand()%4;
		if (movement == 0){
			if ((walk[x+1][y] == '.') && (x < n-1)){
				walk[++x][y] = ++ch;
			}
		}
		else if (movement == 1){
			if ((walk[x-1][y] == '.') && (x > 0)){
				walk[--x][y] = ++ch;
			}
		}
		else if (movement == 2){
			if ((walk[x][y+1] == '.') && (y < m-1)){
				walk[x][++y] = ++ch;
			}
		}
		else if (movement == 3){
			if ((walk[x][y-1] == '.') && (y > 0)){
				walk[x][--y] = ++ch;
			}
		}
		
		if (((walk[x+1][y] != '.') || (x+1 > n-1)) && ((walk[x-1][y] != '.') || (x-1 < 0)) && ((walk[x][y+1] != '.') || (y+1 > m-1)) && ((walk[x][y-1] != '.') || (y-1 < 0))){
			break;
		}
		else {
			continue;
		}
		
	}
	printf ("Walked until letter %c\n", ch);
}

void print_array (int n, int m, char walk[n][m]){
	int i, j;
	for (i=0; i<n; i++){
		printf ("\n");
		for (j=0; j<m; j++){
			printf("%c", walk[i][j]);
			printf(" ");
		}
	}
	printf ("\n");
}