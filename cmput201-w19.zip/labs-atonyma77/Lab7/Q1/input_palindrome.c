#include "palindrome.h"
#include <stdio.h>
#include <string.h>

int main (void) {
	char input[102]; //max character input is 100, but array must allocate space for a newline character and '\0'
	printf ("Enter a message: ");
	fgets(input, 102, stdin);
	
	input[strlen(input)] = '\0';//add null terminating character
	
	if (check_palindrome(input, strlen(input)+1)){
		printf("Is a palindrome\n");
	}
	else{
		printf("Not a palindrome\n");
	}
	return 0;
}