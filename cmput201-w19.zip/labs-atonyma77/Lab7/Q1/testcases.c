#include "palindrome.h"
#include <stdio.h>
#include <string.h>
int main(void){
	//Checking for an input with whitespace 
	char input1[6] = {"he eh"};
	if (check_palindrome(input1, 6)){
		printf("Test passed\n");
	}
	else{
		printf("Test failed\n");
	}
	
	//Checking for an input with whitespace and non letter characters
	char input2[7] = {"he eh?"};
	if (check_palindrome(input2, 7)){
		printf("Test passed\n");
	}
	else{
		printf("Test failed\n");
	}
	
	//Checking for an input with a capital
	char input3[5] = {"Yeey"};
	if (check_palindrome(input3, 5)){
		printf("Test passed\n");
	}
	else{
		printf("Test failed\n");
	}
	
	//Checking for an single letter input
	char input4[2] = {"a"};
	if (check_palindrome(input4, 2)){
		printf("Test passed\n");
	}
	else{
		printf("Test failed\n");
	}
	
	
	//Checking for an input without whitespace, capitals, and extra characters
	char input5[5] = {"ollo"};
	if (check_palindrome(input5, 6)){
		printf("Test passed\n");
	}
	else{
		printf("Test failed\n");
	}
	
	return 0;
}