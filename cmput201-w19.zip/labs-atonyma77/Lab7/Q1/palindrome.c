#include "palindrome.h"
#include <stdio.h>
#include <string.h>

int check_palindrome(char input [], int inputLen){
	//Input Length reflects the length of the string but also allocates an additional space for the null terminating character
	char revInput[102] = {0}, cleanInput[101] = {0};
	char *revp = revInput;
	char *cleanp = cleanInput;
	char *p = (input + inputLen)-2; // assign pointer to point to the last element in the input (not including the null terminating character)
	for (; p >= input; p--){
		if (*p >= 'A' && *p <= 'Z'){
			*p += ('a' - 'A');
			*revp = *p;
			revp++;
		}
		else if(*p >= 'a' && *p <= 'z'){
			*revp = *p;
			revp++;
		}
	}
	
	p = input;
	
	for(; p < input + inputLen; p++){
		if(*p >= 'a' && *p <= 'z'){
			*cleanp = *p;
			cleanp++;
		}
	}
	
	if (strcmp(cleanInput, revInput) == 0){
		return 1;
	}
	
	return 0;
}
