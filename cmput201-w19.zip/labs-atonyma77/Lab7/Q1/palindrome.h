#ifndef PALINDROME_H
#define PALINDROME_H

int check_palindrome(char input [], int inputLen);


#endif /* PALINDROME */