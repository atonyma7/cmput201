#include <stdio.h>
#include <string.h>

int get_extension(const char *file_name);

int main(int argc, char *argv[]){
	printf ("%d\n", get_extension(argv[1]));
	return 0;
}

int get_extension(const char *file_name){
	char *p;
	p = strrchr(file_name, '.');
	static char *extensions[5] = {".txt", ".out", ".bkp", ".dot", ".tx"};
	int index = 0;
	
	if (p == NULL){
		return -1;
	}
	
	else{
	
		for (; index < 5; index++){
			if (strcmp (extensions[index], p) == 0){
				return index; 
			}
		}
	}
	
	return -1;
	
}