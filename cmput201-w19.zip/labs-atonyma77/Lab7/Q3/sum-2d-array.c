#include <stdio.h>
#include <string.h>
#define LEN 10

int sum_two_dimensional_array(int a[][LEN], int n){

	int *p = *a;
	int sum = 0;
	for (; p < *a + (n*LEN); p++){
	 sum += *p;
	}

	return sum;
}

int main(void){
	int numbers[2][LEN] = {{1,2,3,4,5,6,7,8,9,10},
				{2,3,4,5,6,7,8,9,10,11}};
	
	printf("%d\n", sum_two_dimensional_array(numbers, 2));
	
	return 0;
}