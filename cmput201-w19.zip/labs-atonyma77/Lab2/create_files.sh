#!/bin/bash

echo "This is f1" > f1.txt

echo "This is F1
" > f2.txt


