#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[])
{
        FILE *fp = fopen(argv[1], "r");
        int y1, m1, d1, y2, m2, d2;

        fscanf(fp, "%d/%d/%d", &m1, &d1, &y1);
        printf("Enter a date to compare to (mm/dd/yy):");
        scanf("%d/%d/%d", &m2, &d2, &y2);

        if((m1>=1 && m1<=12) && (m2>=1 && m2<=12)){}
        else {
                fprintf(stderr, "Wrong Date Format\n");
                exit(4);
        }

        if((y1>=1 && y1<=19) && (y2>=1 && y2<=19)){}
        else {
                fprintf(stderr, "Wrong Date Format\n");
                exit(4);
         }

        switch (m1){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                        if((d1>=1 && d1<=31)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;
                case 4:
                case 6:
                case 9:
                case 11:
                        if((d1>=1 && d1<=30)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;

                case 2:
                        if((d1>=1 && d1<=28)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;

        }

        switch (m2){
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                        if((d2>=1 && d2<=31)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;
                case 4:
                case 6:
                case 9:
                case 11:
                        if((d2>=1 && d2<=30)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;

                case 2:
                        if((d2>=1 && d2<=28)){}
                        else{
                                fprintf(stderr, "Wrong Date Format\n");
                                exit(4);
                        }
                        break;
        }


        if (y1 > y2){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m2, d2, y2, m1, d1, y1);
        }
        else if (y2 > y1){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m1, d1, y1, m2, d2, y2);
        }
        else if (m1 > m2){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m2, d2, y2, m1, d1, y1);
        }
        else if (m2 > m1){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m1, d1, y1, m2, d2, y2);
        }
        else if (d1 > d2){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m2, d2, y2, m1, d1, y1);
        }
        else if (d2 > d1){
                printf("%.2d/%.2d/%.2d is earlier than %.2d/%.2d/%.2d\n", m1, d1, y1, m2, d2, y2);
        }
        return 0;
}
