#!/bin/bash

./create_files.sh

diff -i f1.txt f2.txt
