#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static int myCompare(const void* a, const void* b) 
{ 
  
    return strcmp(*(const char**)a, *(const char**)b); 
}
 
int main(void){
	char *words[100];
	char input[20];
	int count = 0;
	while (count < 100){
		printf("Enter word: ");
		fgets(input, 20, stdin);
		input[strlen(input)-1] = '\0';
		if (input[0] == '\0'){
			break;
		}
		char *word = malloc(strlen(input)+1);
		strcpy(word, input);
		words[count] = word;
		count++;
	}
	qsort(words, count, sizeof( char*), myCompare); 
	
	printf("In sorted order: ");
	for (int index = 0; index < count; index++){
		printf("%s ", words[index]);
	}
	
	for (int index = 0; index < count; index++){
		free(words[index]);
	}
	
	return 0;
}