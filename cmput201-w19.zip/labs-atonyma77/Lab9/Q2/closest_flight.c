#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

struct flight_times{
		int departure_time;
		int arrival_time;
};

void print_closest_time(int departure_time, int arrival_time);

int main(){
	struct flight_times flights[4] = {
		{.departure_time = 8*60, .arrival_time = 10*60 + 16},
		{.departure_time = 9*60 + 43, .arrival_time = 11*60 + 52},
		{.departure_time = 11*60 + 19, .arrival_time = 13*60 + 31},
		{.departure_time = 12*60 + 47, .arrival_time = 15*60},
	};
	
	int input_hours, input_mins;
	printf("Enter a 24-hour time: ");
	scanf("%d:%d", &input_hours, &input_mins);
	
	int total_input_mins = input_hours*60 + input_mins;
	
	int closest_index = 0;
	int closest = abs(total_input_mins - flights[0].departure_time);
	int difference;
	for (int index = 1; index < 4; index++){
		difference = abs(total_input_mins - flights[index].departure_time);
		if (difference < closest){
			closest = difference;
			closest_index = index;
		}
	}
	
	print_closest_time(flights[closest_index].departure_time, flights[closest_index].arrival_time);
	return 0;
}

void print_closest_time(int departure_time, int arrival_time){
	
	bool afternoon = false;
	int departure_hour, departure_mins, arrival_hour, arrival_mins;
	departure_hour = departure_time / 60;
	departure_time = departure_time % 60;
	
	if (departure_hour >= 12){
		afternoon = true;
	}	
	if (departure_hour >= 13){
		departure_hour = departure_hour - 12;
	}
	
	departure_mins = departure_time;
	
	if (afternoon){
		printf("Closest departure time is %.2d:%.2d p.m, ", departure_hour, departure_mins);
	}
	else{
		printf("Closest departure time is %.2d:%.2d a.m, ", departure_hour, departure_mins);
	}
	
	afternoon = 0;
	arrival_hour = arrival_time / 60;
	arrival_time = arrival_time % 60;
	
	if (arrival_hour >= 12){
		afternoon = true;
	}	
	if (arrival_hour >= 13){
		arrival_hour = arrival_hour - 12;
	}
	
	arrival_mins = arrival_time;
	
	if (afternoon){
		printf("arriving at %.2d:%.2d p.m\n", arrival_hour, arrival_mins);
	}
	else{
		printf("arriving at %.2d:%.2d a.m\n", arrival_hour, arrival_mins);
	}
	
	return;
}