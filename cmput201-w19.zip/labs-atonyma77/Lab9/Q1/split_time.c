#include <stdio.h>
#include <stdlib.h>
#define SECONDS_IN_DAY 86400

typedef struct {
		int hours;
		int minutes;
		int seconds;
}time;

time split_time(long total_seconds);


int main(void){
	time Time;
	long total_seconds;
	printf("Enter time as seconds since midnight: ");
	scanf("%ld", &total_seconds);
	Time = split_time(total_seconds);
	printf("%.2d:%.2d:%.2d\n", Time.hours, Time.minutes, Time.seconds);
	return 0;
}

time split_time(long total_seconds){
	int hours;
	int minutes;
	int seconds;
	total_seconds = total_seconds % SECONDS_IN_DAY;
	
	hours = total_seconds / 3600;
	total_seconds = total_seconds % 3600;
	
	minutes = total_seconds / 60;
	total_seconds = total_seconds % 60;
	
	seconds = total_seconds;
	
	time Time = {.hours = hours, .minutes = minutes, .seconds = seconds};
	
	return Time;
}