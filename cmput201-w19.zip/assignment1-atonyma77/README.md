Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

This program will encrypt/decrypt input files based on a given encryption/decryption mapping scheme. It will read from a text file, and print the output based on the given mapping scheme and encryption/decryption mode. 

Running "make" in the command terminal will compile the program "encrypt.c" into an executeable called "encrypt." From there, enter "./encrypt -t 'mappingfile' -m 'encryption mode' -i 'inputfile'" into the terminal to run the program. 

Here are the descriptions of the files in the repository:

encrypt.c - This is the source code for the encrypt program
Makefile - This is the Makefile that complies the executeable, running make clean will remove the executeable
mapping_decryption.csv - This is the decryption mapping scheme
mapping_encryption.csv - This is the encryption mapping scheme
output_decryption.txt - This is the expected output for the decryption case
output_encryption.txt - This is the expected output for the encryption case
input_decryption.txt - This is the input for the decryption case
input_encryption.txt - This is the input for the encryption case
test_decryption.sh - This script checks the decryption case
test_encryption.sh - This script checks the encryption case

Credits:

https://www.tutorialspoint.com/

https://stackoverflow.com/

https://fresh2refresh.com/

https://guide.freecodecamp.org/c/

https://en.wikipedia.org/

https://www.programiz.com/c-programming/c-arrays/

Authors:
Anthony Ma
