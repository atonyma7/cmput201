#!/bin/bash
./encrypt -t mapping_decryption.csv -m 2 -i input_decryption.txt
