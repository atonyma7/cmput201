#!/bin/bash
./encrypt -t mapping_encryption.csv -m 1 -i input_encryption.txt
