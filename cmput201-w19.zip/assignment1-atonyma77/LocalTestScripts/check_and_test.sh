#!/bin/bash

#runs check_general_requirements_local.sh and test_program.sh
./LocalTestScripts/check_general_requirements_local.sh
./LocalTestScripts/test_program_local.sh

