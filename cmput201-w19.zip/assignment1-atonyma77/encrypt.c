//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

FILE *fp1; // declare file pointer as a global variable for later use
void encrypt(char plainText[], int inputLength);
void decrypt(char plainText[], int inputLength);


int main (int argc, char *argv[]){
	int index, mode, mappingindex, inputindex, flg1, flg2, flg3; 
	char word[22], line[5], ch1, ch2; // the arrays must allocate space for both the newline character in each line and the null terminating character ("\0").
	
	
	//Checking for the argv[] index for the various flags entered in the command line
	
	for (index = 0; index < argc; index++){
		if (strcmp(argv[index], "-t") == 0){
			mappingindex = index;
			flg1 = 1;
		}
		else if (strcmp(argv[index], "-m") == 0){
			mode = atoi(argv[index+1]);
			flg2 = 1;
		}
		else if (strcmp(argv[index], "-i") == 0){
			inputindex = index;
			flg3 = 1;
		}
	}
	
	//exit if there are incorrect flags entered in the command line, or if there are a incorrect number of arguments passed to the program
	
	if ((argc != 7) || (flg1 !=1 ) || (flg3 !=1 )|| (flg2 != 1 )) {
		fprintf(stderr, "Usage: ./encrypt -t <mappingfile> -m <encryption mode> -i <inputfile>\n");
		exit (7);
	}
	
	//open the mapping file and assign it to the global variable, also open the other
	
	fp1 = fopen(argv[mappingindex+1], "r");
	FILE *fp2 = fopen(argv[inputindex+1], "r");
	
	char c;
	int lines = 0, lineLen = 0;
	
	//check if arguments passed are valid or not
	
	if (fp1 == NULL){
		fprintf (stderr, "Error: Mapping File %s does not exist\n", argv[mappingindex+1]);
		exit (3);
	}
	
	if (fp2 == NULL){
		fprintf (stderr, "Error: Input word file %s does not exist\n", argv[inputindex+1]);
		exit (5);
	}
	
	if (mode !=1 && mode !=2){
		fprintf (stderr, "You entered %d. Sorry, your mode must be 1 for encryption or 2 for decryption\n", mode);
		exit (6);
	}
	
	//Check if there file format is valid
	
	while  ((c = fgetc(fp1)) != EOF){ 
		lineLen++;
		if (c == '\n'){
			if (lineLen == 4){ // count the number of characters in each line
				lines++;
				lineLen = 0;
			}
			else{
				fprintf(stderr, "Error: The format of mapping file %s is incorrect\n", argv[mappingindex+1]);
				exit (4);
			}
		}
	}
	
	rewind(fp1); // rewind since fp1 is now pointing to the EOF character.
	
	
	//check for a valid number of lines 
	
	if (lines != 25){
		fprintf(stderr, "Error: The format of mapping file %s is incorrect\n", argv[mappingindex+1]);
		exit (4);
	}
	
	int plainCount[26] = {0}, cipherCount[26] = {0};
	
	// check if the format of the lines is "lowercase,lowercase" also count for the frequency of the characters that appear the file by storing them in plainCount and cipherCount
	while (fgets(line, sizeof(line), fp1) != NULL){
		if (sscanf(line, "%c,%c", &ch1, &ch2) == 2){
			if ((ch1 >= 'a' && ch1 <= 'z') && (ch2 >= 'a' && ch2 <= 'z')){
				index = ch1 - 'a';
				plainCount[index]++;
				index = ch2 - 'a';
				cipherCount[index]++;
			}
			else{
				fprintf(stderr, "Error: The format of mapping file %s is incorrect\n", argv[mappingindex+1]);
				exit (4);
			}
		}
		
		else {
			fprintf(stderr, "Error: The format of mapping file %s is incorrect\n", argv[mappingindex+1]);
			exit (4);
		}
	}
	
	rewind(fp1); // rewind since fp1 is now pointing to the EOF character.
	
	
	//exit if the frequency of each letter does not equal 1
	for (index = 0; index<26; index++){
		if (plainCount[index] != 1 || cipherCount[index] != 1){
			fprintf(stderr, "Error: The format of mapping file %s is incorrect\n", argv[mappingindex+1]);
			exit (4);
		}
	}
	
	
	/* end of error checking*/
	
	
	if (mode == 1){
		while (fgets(word, sizeof(word), fp2) != NULL)  {
			encrypt(word, sizeof(word));
		}
	}
	
	if (mode == 2){
		while (fgets(word, sizeof(word), fp2) != NULL)  {
			decrypt(word, sizeof(word));
		}
	}
	
	//closing files
	fclose(fp1);
	fclose(fp2);
	
	return 0;
}

void encrypt(char plainText[], int inputLength){
	char ch1, ch2, line[5];
	int letterindex, len;
	
	// for each word, check each letter with all lines of the .csv file, break if letter is found and replace letter with corresponding character.
	for (letterindex=0; letterindex < inputLength; letterindex++){
		if (plainText[letterindex] == '\n') 
			plainText[letterindex] = '\0';
		while (fgets(line, sizeof(line), fp1) != NULL){
			sscanf(line, "%c,%c", &ch1, &ch2);
			if (plainText[letterindex] == ch1){
				plainText[letterindex] = ch2;
				break;
			}
		}
		rewind(fp1);
	}
	
	len = strlen(plainText) - 1;
	for (; len >= 0; len--){
		fprintf(stdout, "%c", plainText[len]);
	}
	fprintf(stdout, "\n");
	return;
}

void decrypt(char plainText[], int inputLength){
	char ch1, ch2, line[5];
	int letterindex, len;
	
	// for each word, check each letter with all lines of the .csv file, break if letter is found and replace letter with corresponding character.
	for (letterindex=0; letterindex < inputLength; letterindex++){
		if (plainText[letterindex] == '\n') 
			plainText[letterindex] = '\0';
		while (fgets(line, sizeof(line), fp1) != NULL){
			sscanf(line, "%c,%c", &ch1, &ch2);
			if (plainText[letterindex] == ch2){
				plainText[letterindex] = ch1;
				break;
			}
		}
		rewind(fp1);
	}
	
	len = strlen(plainText) - 1;
	for (; len >= 0; len--){
		fprintf(stdout, "%c", plainText[len]);
	}
	fprintf(stdout, "\n");
	return;
}


