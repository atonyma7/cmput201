Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

This program will solve any word search puzzle up to 100*100 using the Rabin-Karp algorithm

Running "make" in the command terminal will compile the source code files "wordSearch2D.c", "puzzle2D.c", and "puzzle2D.h" into an executeable called "wordSearch2D" From there, enter "./wordSearch2D -p <puzzle_file> -l <word_length> -w <wordlist_file> [-o <solution_file>]" into the terminal to run the program, the -o flag specifies a optional filename for the output to be printed too.
Here are the descriptions of the files in the repository:

wordSearch2D.c - This is the source code for the program

puzzle2D.c - This is the source code for the functions of the program

puzzle2D.h - This header file contains the function definitions

Makefile - This is the Makefile that complies the executeable, running make clean will remove the executeable

wordlist.txt - Contains the list of words to be found in the puzzle

puzzle.txt - Contains the puzzle of n*n dimensions where n is an integer

expected_soln.txt - This contains the expected output of the program

test_program.sh - This script checks the test case

Credits:

https://www.tutorialspoint.com/

https://stackoverflow.com/

http://analgorithmaday.blogspot.com/

https://guide.freecodecamp.org/c/

https://en.wikipedia.org/

Authors: Anthony Ma