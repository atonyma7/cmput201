#! /bin/bash
./LocalTestScripts/check_general_requirements_local.sh
./LocalTestScripts/test_program_local.sh
