//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#ifndef PUZZLE2D_H
#define PUZZLE2D_H


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define P 101
#include <stdbool.h>


long long hash(char string[], int stringLength);
long long myPow(int x,int n);
long long rollingHash (long long subHash, int wordLength, char removedLetter, char newLetter);
void checkRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkDown(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkUp(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkTopLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkBottomLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkBottomRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);
void checkTopRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]);

#endif /* PUZZLE2D_H */