//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#include "puzzle2D.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define P 101
#include <stdbool.h>

int main(int argc, char *argv[]){
	char words[102][102] = {{0}};
	int index = 0, wordIndex, puzzleIndex, wordLength, flg1, flg2, flg3;
	int outputIndex = 0;
	
	// loop through argv[] and find the correct arguments
	for (index = 0; index < argc; index++){
		if (strcmp(argv[index], "-w") == 0){
			wordIndex = index;
			flg1 = 1;
		}
		else if (strcmp(argv[index], "-l") == 0){
			wordLength = atoi(argv[index+1]);
			flg2 = 1;
		}
		else if (strcmp(argv[index], "-p") == 0){
			puzzleIndex = index;
			flg3 = 1;
		}
		else if (strcmp(argv[index], "-o") == 0){
			outputIndex = index;
		}
	}
	
	// check for correct flags, exit if a required flag is missing
	if ((flg1 !=1 ) || (flg3 !=1 )|| (flg2 != 1 )) {
		fprintf(stderr, "Usage: ./wordSearch2D -p <puzzle_file> -l <word_length> -w <wordlist_file> [-o <solution_file>]");
		exit (6);
	}
	
	FILE *fp1 = fopen(argv[puzzleIndex+1], "r");
	FILE *fp2 = fopen(argv[wordIndex+1], "r");
	
	// check if files exist
	
	if (fp1 == NULL){
		fprintf (stderr, "Error: Puzzle file %s does not exist\n", argv[puzzleIndex+1]);
		exit (4);
	}
	
	if (fp2 == NULL){
		fprintf (stderr, "Error: Wordlist file %s does not exist\n", argv[wordIndex+1]);
		exit (5);
	}
	
	//get the dimensions of both files
	char line[102];
	fgets(line, sizeof(line), fp1);
	
	char puzzle[strlen(line)][strlen(line)+1]; //line must contain space for newline character and null terminating character
	rewind(fp1);
	
	char word[102];
	fgets(word, sizeof(word), fp2);
	rewind(fp2);
	
	//check to exit if the wordlength and length of the words in the file are equal
	
	for (index = 0; index < 102; index++){
		if ((fgets(words[index], sizeof(words[index]), fp2)) != NULL){
			if (words[index][strlen(words[index]) - 1] == '\n'){
				words[index][strlen(words[index]) - 1] = '\0';
				}
			if (strlen(words[index]) != wordLength){
				fprintf(stderr, "Encountered Error");
				exit (7);
			}
		}
		else{
			break;
		}
	}
	
	
	rewind(fp2);
	
	
	int wordStrLen = strlen(word);
	int lineLength = strlen(line);
	
	// check for how many lines there are in the puzzle file
	int lineCount = 0;
	for (index = 0; index < 102; index++){
		if ((fgets(puzzle[index], sizeof(puzzle[index]), fp1)) != NULL){
			if (puzzle[index] != NULL){
				lineCount++;
			}
			if (words[index][strlen(words[index]) - 1] != '\0'){
				words[index][strlen(words[index]) - 1] = '\0';
			}
		}
		else{
			break;
		}
	}
	
	// check if the word length argument is valid
	if (wordLength < 1 || wordLength > lineLength -1){
		fprintf(stderr, "Encountered Error");
		exit (7);
	}
	
	// check if the puzzle file is n*n
	if (lineLength-1 != lineCount){
		fprintf(stderr, "Encountered Error");
		exit (7);
	}
	
	//check if the words in the file are of the correct length
	if (wordStrLen-1 != wordLength){
		fprintf(stderr, "Encountered Error");
		exit (7);
	}
	
	//read the words into a 2d array
	for (index = 0; index < 102; index++){
		if ((fgets(words[index], sizeof(words[index]), fp2)) != NULL){
			if (words[index][strlen(words[index]) - 1] == '\n'){
				words[index][strlen(words[index]) - 1] = '\0';
			}
		}
		else{
			break;
		}
	}
	
	words[index][strlen(words[index])] = '\0';
	
	//Hash each word in the words array and store them in a seperate array
	long long wordsHash[102] = {0};
	for (index = 0; index < 102; index++){
		wordsHash[index] = hash(words[index], wordLength+1);
	}
	
	// stores the indes and direction of the arrays
	int foundIndex[102][3] = {{0}};
	
	
	long long hashTable[102][102] = {0};
	
	checkRight(strlen(line), strlen(line)+1, puzzle, 102, 102, words, hashTable, wordsHash, wordLength+1, foundIndex);
	
	long long leftHashTable[102][102] = {{0}};
	
	checkLeft(strlen(line), strlen(line)+1, puzzle, 102, 102, words, leftHashTable, wordsHash, wordLength+1, foundIndex);
	
	long long downHashTable[102][102] = {{0}};
	
	checkDown(strlen(line), strlen(line)+1, puzzle, 102, 102, words, downHashTable, wordsHash, wordLength+1, foundIndex);
	
	long long upHashTable[102][102] = {{0}};
	
	checkUp(strlen(line), strlen(line)+1, puzzle, 102, 102, words, upHashTable, wordsHash, wordLength+1, foundIndex);
	
	long long topLeftTable[102][102] = {{0}};

	checkTopLeft(strlen(line), strlen(line)+1, puzzle, 102, 102, words, topLeftTable, wordsHash, wordLength+1, foundIndex);
	
	long long bottomLeftTable[102][102] = {{0}};
	
	checkBottomLeft(strlen(line), strlen(line)+1, puzzle, 102, 102, words, bottomLeftTable, wordsHash, wordLength+1, foundIndex);
	
	long long bottomRightTable[102][102] = {{0}};
	
	checkBottomRight(strlen(line), strlen(line)+1, puzzle, 102, 102, words, bottomRightTable, wordsHash, wordLength+1, foundIndex);
	
	long long topRightTable[102][102] = {{0}};
	
	checkTopRight(strlen(line), strlen(line)+1, puzzle, 102, 102, words, topRightTable, wordsHash, wordLength+1, foundIndex);
	
	printf("\n");
	
	FILE* fp3 = fopen("output.txt", "w");
	
	//specify optional argument if given
	if (outputIndex != 0){
		fp3 = fopen(argv[outputIndex+1], "w");
	}
	
	//print the output
	for (index = 0; index < 102; index++){
		if (words[index][0] != 0){
		fprintf(fp3, "%s;(%d,%d);%d\n", words[index], foundIndex[index][0], foundIndex[index][1], foundIndex[index][2]);
		}
	}
	fclose(fp3);
	
	
	
	//DO NEXT: need a hash function to convert string into hash value, need a function to construct consecutive hashes for a line of letters. 
	return 0;
}