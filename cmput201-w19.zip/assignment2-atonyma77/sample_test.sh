#!/bin/bash
./wordSearch2D -w wordlist.txt -l 3 -p puzzle.txt                                                                                                                                                         zzle.txt

