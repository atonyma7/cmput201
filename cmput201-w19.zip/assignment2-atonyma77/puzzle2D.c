//Anthony Ma, 153302, amma, LEC B1, Sarah Nadi, LAB H03, Baihong Qi, Copyright 2019 \Anthony Ma

#include "puzzle2D.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define P 101
#include <stdbool.h>

// CHECKS RIGHT TO LEFT
void checkRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;

	// CREATES SUBSTRING FIRST
	for (index = 0; index < puzzleL-2; index++){
		for (index2 = 0; index2 < wordStrLen-1; index2++){
			substring[index2] = puzzle[index][index2];
		}
		substring[index2] = '\0';
		// BUILDS HASH USING THE RABIN KARP ALGORITHM AND THEN APPENDS THE VALUES TO A HASH TABLE
		
		subHash = hash(substring, wordStrLen);
		hashTable[index][0] = subHash;
		for (startIndex = 0; startIndex < (puzzleL-2) - (wordStrLen-1); startIndex++){
			hashTable[index][startIndex+1] = rollingHash (subHash, wordStrLen, puzzle[index][startIndex], puzzle[index][index2]);
			subHash = rollingHash (subHash, wordStrLen, puzzle[index][startIndex], puzzle[index][index2]);
			index2++;
		}
	}
	
	int wordindex = 0;
	
	//CHECK IF ANY OF THE WORD HASHES IS FOUND.
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){
					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 1;
				}
			}
		}	
	}
	return;
}

// CHECKS LEFT TO RIGHT


void checkLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = 0; index < puzzleL-2; index++){
		letterCount = 0;
		for (index2 = (puzzleL-2)-1; index2 >= (puzzleL-2) - (wordStrLen-1); index2--, letterCount++){
			substring[letterCount] = puzzle[index][index2];
		}
		substring[letterCount] = '\0';
		
		subHash = hash(substring, wordStrLen);
		hashTable[index][(puzzleL-2)-1] = subHash;
		for (startIndex = (puzzleL-2)-1; startIndex >= (wordStrLen-1); startIndex--){
			hashTable[index][startIndex-1] = rollingHash (subHash, wordStrLen, puzzle[index][startIndex], puzzle[index][index2]);
			subHash = rollingHash (subHash, wordStrLen, puzzle[index][startIndex], puzzle[index][index2]);
			index2--;
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){
					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 2;
				}
			}
		}	
	}
	return;
}

//CHECK DOWNWARDS

void checkDown(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;


	for (index = 0; index < puzzleL-2; index++){
		for (index2 = 0; index2 < wordStrLen-1; index2++){
			substring[index2] = puzzle[index2][index];
		}
		substring[index2] = '\0';
		
		
		subHash = hash(substring, wordStrLen);
		
		hashTable[0][index] = subHash;
		for (startIndex = 0; startIndex < (puzzleH-1) - (wordStrLen-1); startIndex++){
			hashTable[startIndex+1][index] = rollingHash (subHash, wordStrLen, puzzle[startIndex][index], puzzle[index2][index]);
			subHash =rollingHash (subHash, wordStrLen, puzzle[startIndex][index], puzzle[index2][index]);
			index2++;
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){

					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 3;
				}
			}
		}	
	}
	return;
}

//CHECKS UPWARDS

void checkUp(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = 0; index < puzzleL-2; index++){
		letterCount = 0;
		for (index2 = (puzzleL-2)-1; index2 >= (puzzleL-2) - (wordStrLen-1); index2--, letterCount++){
			substring[letterCount] = puzzle[index2][index];
		}
		substring[letterCount] = '\0';
		
		
		subHash = hash(substring, wordStrLen);
		hashTable[(puzzleL-2)-1][index] = subHash;
		for (startIndex = (puzzleL-2)-1; startIndex >= (wordStrLen-1); startIndex--){
			hashTable[startIndex-1][index] = rollingHash (subHash, wordStrLen, puzzle[startIndex][index], puzzle[index2][index]);
			subHash = rollingHash (subHash, wordStrLen, puzzle[startIndex][index], puzzle[index2][index]);
			index2--;
		}
	}
	
	int wordindex = 0;

	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){
					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 4;
				}
			}
		}	
	}
	return;
}

// CHECKS THE LEFT COLUMN AND THE TOP ROW, TOP LEFT TO BOTTOM RIGHT,

void checkTopLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = 0; index < puzzleL-2; index++){
		int x = index, y = 0;
		letterCount = 0;
		for (x = index, y=0; (x < puzzleL-2) && (y < puzzleL-2) && (letterCount < wordStrLen-1); x++, y++){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[index][0] = subHash;
			
			int temp = index;
			for (startIndex = 0;  (x < puzzleL-2) && (y < puzzleL-2); startIndex++){
				hashTable[temp+1][startIndex+1] = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				subHash = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				y++;
				x++;
				temp++;
			}
		}
	}
	
	for (index = 1; index < puzzleL-2; index++){
		int x = 0, y = index;
		letterCount = 0;
		for (x = 0, y= index; (x < puzzleL-2) && (y < puzzleL-2) && (letterCount < wordStrLen-1); x++, y++){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[0][index] = subHash;
			int temp = index;
			for (startIndex = 0;  (x < puzzleL-2) && (y < puzzleL-2); startIndex++){
				hashTable[startIndex+1][temp+1] = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				subHash = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				y++;
				x++;
				temp++;
			}
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){
					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 5;
				}
			}
		}	
	}
	return;
}

//CHECKS THE LEFT COLUMN AND BOTTOM ROW, BOTTOM LEFT TO TOP RIGHT

void checkBottomLeft(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = (puzzleL-2)-1; index >= 0; index--){
		int x = index, y = 0;
		letterCount = 0;
		for (x = index, y=0; (x >= 0) && (y < puzzleL-2) && (letterCount < wordStrLen-1); x--, y++){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[index][0] = subHash;
			
			int temp = index;
			for (startIndex = 0;  (x >= 0) && (y < puzzleL-2); startIndex++){
				hashTable[temp-1][startIndex+1] = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				subHash = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				y++;
				x--;
				temp--;
			}
		}
	}
	
	for (index = 1; index < (puzzleL-2); index++){
		int x =(puzzleL-2)-1;
		int y = index;
		int letterCount = 0;
		for (x = (puzzleL-2)-1, y= index; (x >= 0) && (y < puzzleL-2) && (letterCount < wordStrLen-1); x--, y++){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[(puzzleL-2)-1][index] = subHash;
			
			int temp = index;
			for (startIndex = (puzzleL-2)-1;  (x >= 0) && (y < puzzleL-2); startIndex--){
				hashTable[startIndex-1][temp+1] = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				subHash = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				y++;
				x--;
				temp++;
			}
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){
					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 7;
				}
			}
		}	
	}
	return;
}

//CHECKS BOTTOM ROW AND RIGHTMOST COLUMN, BOTTOM RIGHT TO TOP LEFT

void checkBottomRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = (puzzleL-2)-1; index >= 0; index--){
		int x = index, y = (puzzleL-2)-1;
		letterCount = 0;
		for (x = index, y= (puzzleL-2)-1; (x >= 0) && (y >= 0) && (letterCount < wordStrLen-1); x--, y--){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[index][(puzzleL-2)-1] = subHash;
			
			int temp = index;
			for (startIndex = (puzzleL-2)-1;  (x >= 0) && (y >= 0); startIndex--){
				hashTable[temp-1][startIndex-1] = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				subHash = rollingHash(subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				y--;
				x--;
				temp--;
			}
		}
	}
	
	for (index = (puzzleL-2)-2; index >= 0; index--){
		int x = (puzzleL-2)-1, y = index;
		letterCount = 0;
		for (x = (puzzleL-2)-1, y= index; (x >= 0) && (y >= 0) && (letterCount < wordStrLen-1); x--, y--){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			subHash = hash(substring, wordStrLen);
			hashTable[(puzzleL-2)-1][index] = subHash;
			
			int temp = index;
			for (startIndex = (puzzleL-2)-1;  (x >= 0) && (y >= 0); startIndex--){
				hashTable[startIndex-1][temp-1] = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				subHash = rollingHash(subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				y--;
				x--;
				temp--;
			}
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){

					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 6;
				}
			}
		}	
	}
	return;
}	

//CHECK TOP ROW AND RIGHTMOST COLUMN, TOP RIGHT TO BOTTOM LEFT

void checkTopRight(int puzzleH, int puzzleL, char puzzle[][puzzleL], int wordH, int wordL, char words[][wordL], long long hashTable[puzzleH][puzzleL], long long wordsHash[wordH], long long wordStrLen, int foundIndex[wordH][3]) {
	int index = 0;
	int index2 = 0;
	char substring[wordL];
	int startIndex = 0;
	long long subHash = 0;
	int letterCount = 0;

	for (index = 0; index < (puzzleL-2); index++){
		int x = index, y = (puzzleL-2)-1;
		letterCount = 0;
		for (x = index, y= (puzzleL-2)-1; (x < (puzzleL-2)) && (y >= 0) && (letterCount < wordStrLen-1); x++, y--){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
			
			subHash = hash(substring, wordStrLen);
			hashTable[index][(puzzleL-2)-1] = subHash;
			
			int temp = index;
			for (startIndex = (puzzleL-2)-1;  (x < (puzzleL-2)) && (y >= 0); startIndex--){
				hashTable[temp+1][startIndex-1] = rollingHash (subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				subHash = rollingHash(subHash, wordStrLen, puzzle[temp][startIndex], puzzle[x][y]);
				y--;
				x++;
				temp++;
			}
		}
	}
	
	for (index = (puzzleL-2)-2; index >= 0; index--){
		int x = 0, y = index;
		letterCount = 0;
		for (x = 0, y= index; (x < (puzzleL-2)) && (y >= 0) && (letterCount < wordStrLen-1); x++, y--){
			substring[letterCount] = puzzle[x][y];
			letterCount++;
		}
		
		substring[letterCount] = '\0';
		if (letterCount >= wordStrLen-1){
	
			subHash = hash(substring, wordStrLen);
			hashTable[0][index] = subHash;
			
			int temp = index;
			for (startIndex = 0;  (x < (puzzleL-2)) && (y >= 0); startIndex++){
				hashTable[startIndex+1][temp-1] = rollingHash (subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				subHash = rollingHash(subHash, wordStrLen, puzzle[startIndex][temp], puzzle[x][y]);
				y--;
				x++;
				temp--;
			}
		}
	}
	
	int wordindex = 0;
	
	for (index = 0; index < puzzleH; index++){
		for (index2 = 0; index2 < puzzleL; index2++){
			for (wordindex = 0; wordindex < wordH; wordindex++){
				if ((wordsHash[wordindex] == hashTable[index][index2]) && (wordsHash[wordindex] != 0 )){

					foundIndex[wordindex][0] = index;
					foundIndex[wordindex][1] = index2;
					foundIndex[wordindex][2] = 8;
				}
			}
		}	
	}
	return;
}	

//IMPLEMENTS THE ROLLING HASH GIVEN A NEWLETTER AND A LETTER TO BE REMOVED

long long rollingHash (long long subHash, int wordLength, char removedLetter, char newLetter){
		subHash = (subHash - (removedLetter * myPow(P, (wordLength-1) - (1))))*P + newLetter;
	return subHash;
}

// HASHES AN INPUT OF A GIVEN LENGTH

long long hash(char string[], int stringLength){
	int index = 0; 
	long hashValue = 0;
	for (index = 0; index < stringLength; index++){
		hashValue += string[index] * myPow(P, ((stringLength-1) - (1+index)));
	}
	return hashValue;
}

//POWER FUNCTION

long long myPow(int x,int n)
{
    long long i;
    long long power = 1;

    for (i = 0; i < n; ++i)
        power *= x;

    return(power);
}